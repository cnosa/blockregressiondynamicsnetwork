rm(list = ls (all.names = TRUE))

####################
# general settings #
####################

loc     <- "C:/Users/Juan Camilo/Dropbox/PAPERS/NETS/"
dataset <- "fblog"

###### paths
path_data <- paste0(loc, "data/")
path_code <- paste0(loc, "code/")
path_outs <- paste0(loc, "outs/")

source(paste0(path_code, "rfunctions.R"))

###### data
suppressMessages(suppressWarnings(library(sand)))
data(fblog)
Y <- as.matrix(get.adjacency(fblog))
Y <- as.matrix(Y)
I <- dim(Y)[1]
colnames(Y) <- rep("", I)
rownames(Y) <- rep("", I)

I <- dim(Y)[1]
Ycube <- Y

Y <- as.matrix(rep(NA, I*(I-1)/2))
for (i in 1:(I-1)) for (ii in (i+1):I) Y[get_k(i, ii, I)] <- Ycube[i, ii]

save(I, Y, Ycube, file = paste0(path_data, dataset, "_data.RData"))