rm(list = ls (all.names = TRUE))

loc     <- "C:/Users/Juan Camilo/Dropbox/PAPERS/NETS/"
dataset <- "dol"

library(igraph)

load(paste0(loc, "data/", dataset, "_data.RData"))

g  <- graph.adjacency(adjmatrix = Ycube, mode = "undirected", diag = F)
kc <- fastgreedy.community(g)
gt <- as.numeric(membership(kc))

save(gt, file = paste0(loc, "data/", dataset, "_labels.RData"))
