rm(list = ls (all.names = TRUE))

loc     <- "C:/Users/Juan Camilo/Dropbox/PAPERS/NETS/"
dataset <- "fblog"

library(sand)

data(fblog)

gt <- as.numeric(as.factor(V(fblog)$PolParty))

save(gt, file = paste0(loc, "data/", dataset, "_labels.RData"))

