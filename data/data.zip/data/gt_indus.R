rm(list = ls (all.names = TRUE))

loc     <- "C:/Users/Juan Camilo/Dropbox/PAPERS/NETS/"
dataset <- "indus"

gt <- c(as.matrix(read.table(paste0(loc, "data/", dataset, "_labels.txt"), quote="\"", comment.char="")))

library(igraph)
library(clues)
load(paste0(loc, "data/", dataset, "_data.RData"))
g <- graph.adjacency(adjmatrix = Ycube, mode = "undirected", diag = F)
kc <- fastgreedy.community(g)
# length(kc)
# sizes(kc)
# adjustedRand(cl1 = gt, cl2 = as.numeric(membership(kc)))

gt <- as.numeric(membership(kc))

save(gt, file = paste0(loc, "data/", dataset, "_labels.RData"))