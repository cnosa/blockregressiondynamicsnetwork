rm(list = ls (all.names = TRUE))

####################
# general settings #
####################

loc     <- "C:/Users/Juan Camilo/Dropbox/PAPERS/NETS/"
dataset <- "bkham"

###### paths
path_data <- paste0(loc, "data/")
path_code <- paste0(loc, "code/")
path_outs <- paste0(loc, "outs/")

source(paste0(path_code, "rfunctions.R"))

###### data
A <- as.matrix(read.table(paste0(path_data, dataset, ".txt")))
I <- dim(A)[2]
Y <- A[1:I, 1:I]

Y[is.na(Y)] <- 0
Y <- Y + t(Y)
Y[Y != 0] <- 1
Y[Y != 1] <- 0

I <- dim(Y)[1]
Ycube <- Y

Y <- as.matrix(rep(NA, I*(I-1)/2))
for (i in 1:(I-1)) for (ii in (i+1):I) Y[get_k(i, ii, I)] <- Ycube[i, ii]

save(I, Y, Ycube, file = paste0(path_data, dataset, "_data.RData"))