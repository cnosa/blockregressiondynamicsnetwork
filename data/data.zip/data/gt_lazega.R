rm(list = ls (all.names = TRUE))

loc     <- "C:/Users/Juan Camilo/Dropbox/PAPERS/NETS/"
dataset <- "lazega"

library(sand)

data(lazega)

gt <- as.numeric(V(lazega)$Office)

save(gt, file = paste0(loc, "data/", dataset, "_labels.RData"))