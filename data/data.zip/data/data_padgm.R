rm(list = ls (all.names = TRUE))

####################
# general settings #
####################

loc     <- "C:/Users/Juan Camilo/Dropbox/PAPERS/NETS/"
dataset <- "padgm"

###### paths
path_data <- paste0(loc, "data/")
path_code <- paste0(loc, "code/")
path_outs <- paste0(loc, "outs/")

source(paste0(path_code, "rfunctions.R"))

###### data
Y <- as.matrix(read.table(paste0(path_data, "padgm.txt")))
I <- dim(Y)[1]
Ylabs <- 1:I

###### Y symmetric? yes!
sum(Y != t(Y)) == 0

###### take out unconnected actors
zro <- (1:I)[ Y %*% rep(1, I) == 0 ]
if (length(zro) > 0) {
        Y <- Y[-zro, -zro]
        Ylabs <- Ylabs[-zro]
}

Y[is.na(Y)] <- 0
Y[Y != 0 ]  <- 1

sum(Y != t(Y)) == 0

I <- dim(Y)[1]
Ycube <- Y

Y <- as.matrix(rep(NA, I*(I-1)/2))
for (i in 1:(I-1)) for (ii in (i+1):I) Y[get_k(i, ii, I)] <- Ycube[i, ii]

save(I, Y, Ycube, file = paste0(path_data, dataset, "_data.RData"))