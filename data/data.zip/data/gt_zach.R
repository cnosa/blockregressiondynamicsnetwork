rm(list = ls (all.names = TRUE))

loc     <- "C:/Users/Juan Camilo/Dropbox/PAPERS/NETS/"
dataset <- "zach"

library(igraphdata)

data(karate)

gt <- karate[[9]][[3]]$`Faction`

save(gt, file = paste0(loc, "data/", dataset, "_labels.RData"))