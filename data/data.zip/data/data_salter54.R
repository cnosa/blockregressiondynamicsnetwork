rm(list = ls (all.names = TRUE))

####################
# general settings #
####################

loc     <- "C:/Users/Juan Camilo/Dropbox/PAPERS/NETS/"
dataset <- "salter"  # exchange, advise, social

###### paths
path_data <- paste0(loc, "data/")
path_code <- paste0(loc, "code/")
path_outs <- paste0(loc, "outs/")

library(igraph)

source(paste0(path_code, "rfunctions.R"))

type <- c("borrowmoney", "giveadvice", "helpdecision", "keroricecome", "keroricego", "lendmoney", "medic", "nonrel", "rel", "templecompany", "visitcome", "visitgo")

for(h in 1:length(type)) assign(x = paste0("Y", type[h]), value = as.matrix(read.csv(paste0(path_data, "adj_", type[h], "_HH_vilno_54.csv"), header = F)))

exchange_money    <- c(1, 6)
exchange_goods    <- c(4, 5)
interact_socially <- c(8, 10, 11, 12)
personal_decision <- c(2, 3)
medical_advise    <- c(7)
related           <- c(9)        

exchange <- c(exchange_money, exchange_goods)
advice   <- c(personal_decision, medical_advise)
social   <- c(interact_socially, related)

I <- dim(Yborrowmoney)[1]
Ylabs <- 1:I

J <- 3

Ycube <- array(0, c(I, I, J))
for (h in exchange) Ycube[,,1] <- Ycube[,,1] + get(paste0("Y",type[h]))
for (h in advice)   Ycube[,,2] <- Ycube[,,2] + get(paste0("Y",type[h]))
for (h in social)   Ycube[,,3] <- Ycube[,,3] + get(paste0("Y",type[h]))

Ycube[Ycube != 0] <- 1

for (j in 1:J) print(sum(Ycube[,,j] != t(Ycube[,,j])) == 0)

YYY <- Ycube

for (j in 1:J) {
        dataset <- paste0("salter54", j)
        
        Y <- YYY[,,j]
        I <- dim(Y)[1]
        Ycube <- Y
        
        Y <- as.matrix(rep(NA, I*(I-1)/2))
        for (i in 1:(I-1)) for (ii in (i+1):I) Y[get_k(i, ii, I)] <- Ycube[i, ii]
        
        save(I, Y, Ycube, file = paste0(path_data, dataset, "_data.RData"))
}