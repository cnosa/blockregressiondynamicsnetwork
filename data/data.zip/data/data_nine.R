rm(list = ls (all.names = TRUE))

####################
# general settings #
####################

loc     <- "C:/Users/Juan Camilo/Dropbox/PAPERS/NETS/"
dataset <- "nine"

###### paths
path_data <- paste0(loc, "data/")
path_code <- paste0(loc, "code/")
path_outs <- paste0(loc, "outs/")

source(paste0(path_code, "rfunctions.R"))

###### data
dat<-dget(paste0(path_data, dataset, ".txt"))
Y0<-dat[[1]] ; diag(Y0)<-NA  ; Y0<-1*(Y0>0) 
m<-dim(Y0)[1] ; n<-dim(Y0)[2]
X<-array(dim=c(m,n,12))

X[,,1]<-matrix(1,m,n)  #intercept

X[,,2]<-matrix( log(dat[[3]][,1]) ,m,n) # pop
X[,,3]<-matrix( log(dat[[3]][,2]) ,m,n) # gdp
X[,,4]<-matrix( dat[[3]][,3] ,m,n)      # pol

X[,,5]<-matrix( log(dat[[4]][,1]) ,m,n,byrow=T)  # pop
X[,,6]<-matrix( log(dat[[4]][,2]) ,m,n,byrow=T)  # gdp
X[,,7]<-matrix( dat[[4]][,3] ,m,n,byrow=T)       # pol

X[,,8]<-log(dat[[2]][,,4]+1)    # dist
X[,,9]<-log(dat[[2]][,,2]+1)    # imports
X[,,10]<-t(log(dat[[2]][,,2]+1)) # exports
X[,,11]<-dat[[2]][,,3]          # igo

for(p in 2:11) { X[,,p]<- (X[,,p]-mean(X[,,p]))/sd(c(X[,,p])) }

X[,,12]<-X[,,4]*X[,,7]          # polity int                

xnames <- c("intercept",
            "log pop initiator","log gdp initiator","polity initiator",
            "log pop target","log gdp target","polity target" , 
            "log dist","log imports","log exports","igo","polity int" )


dimnames(X) <- list( rownames(Y0),colnames(Y0),xnames) 

X<-X[,,c(1,   2,4,  5,7,  8,11,12)]


Xcols<- cbind( X[,1,2] ,X[,1,3] )
Xrows<- cbind( X[,1,2] ,X[,1,3] )

Y<-Y0
Y[is.na(Y)] <- 0
##

XC<- cbind( exp(X[,1,2]),exp(X[,1,3]),X[,1,4]) 
colnames(XC)<-c("pop","gdp","polity")
##

Y[is.na(Y)] <- 0
Y <- Y + t(Y)
Y[Y != 0] <- 1
Y[Y != 1] <- 0

I <- dim(Y)[1]
Ycube <- Y

Y <- as.matrix(rep(NA, I*(I-1)/2))
for (i in 1:(I-1)) for (ii in (i+1):I) Y[get_k(i, ii, I)] <- Ycube[i, ii]

save(I, Y, Ycube, file = paste0(path_data, dataset, "_data.RData"))